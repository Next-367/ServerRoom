
using UnityEngine;

public class WeaponUpgrade : MonoBehaviour
{
    public int weaponLevel = 1;
    public int maxLevel = 3;

    [Header("Weapon Stats")]
    public int damage = 1;
    public float fireRate = 0.25f;
    public int bulletCount = 1;
    public float spreadAngle = 15f;


    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.U))
        {
            UpgradeWeapon();
        }
    }

    public void UpgradeWeapon()
    {
        if (weaponLevel >= maxLevel)
        {
            Debug.Log("ปืนเลเวลสูงสุดแล้ว!");
            return;
        }

        weaponLevel++;

        if (weaponLevel == 2)
        {
            damage = 2;
            fireRate = 0.15f;
            bulletCount = 1;
        }
        else if (weaponLevel == 3)
        {
            damage = 2;
            fireRate = 0.15f;
            bulletCount = 3;
        }

        Debug.Log(
            "อัปเกรดปืนเป็น Level " + weaponLevel +
            " | Damage: " + damage +
            " | Fire Rate: " + fireRate +
            " | Bullet Count: " + bulletCount
        );
    }
}
